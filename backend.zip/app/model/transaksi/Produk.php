<?php

namespace App\model\transaksi;

use Illuminate\Database\Eloquent\Model;

class Produk extends Model
{
    //
}
