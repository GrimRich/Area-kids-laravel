<?php

namespace App\model\transaksi;

use Illuminate\Database\Eloquent\Model;

class KonfirmasiBayar extends Model
{
    //
}
