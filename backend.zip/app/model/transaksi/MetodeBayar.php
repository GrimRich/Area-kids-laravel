<?php

namespace App\model\transaksi;

use Illuminate\Database\Eloquent\Model;

class MetodeBayar extends Model
{
    //
}
