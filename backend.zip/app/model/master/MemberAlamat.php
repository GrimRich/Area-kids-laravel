<?php

namespace App\model\master;

use Illuminate\Database\Eloquent\Model;

class MemberAlamat extends Model
{
    //
}
