<?php

namespace App\model\master;

use Illuminate\Database\Eloquent\Model;

class Testimoni extends Model
{
    //
}
